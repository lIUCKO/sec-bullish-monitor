# SEC Bullish Monitor — sec-api.io edition

Automatizacija za **bullish SEC filing-e** (Form 4 s A/P kodovima i 8-K s ključnim riječima poput *buyback, raises guidance, agreement, merger*), uz **sec-api.io**.

## Kako radi
- GitHub Actions (cron) svakih X minuta pozove **sec-api.io Query** endpoint.
- Filtrira Form 4 **A/P** i 8-K s bullish ključnim riječima.
- Spremi rezultate u `data/` i generira **RSS** u `public/feed.xml`.
- Commit-a promjene u repo (Inoreader čita feed).

## Postavke (obavezno)
U repo → **Settings → Secrets and variables → Actions** dodaj ove *Repository secrets*:

- `SEC_API_KEY` — tvoj **sec-api.io** API ključ
- `SEC_API_URL` — puni URL do *Query* endpointa iz tvog sec-api dashboarda (npr. `https://api.sec-api.io/query`)

> Skripta će pokušati koristiti `Authorization: Bearer <SEC_API_KEY>`. Ako tvoj račun zahtijeva drugačije (npr. `x-api-key`), promijeni `AUTH_SCHEME` u workflowu.

## Pokretanje
1. Commit-aj sadržaj ovog repoa.
2. Dodaj secrets (gore opisano).
3. Otvori **Actions** → workflow **"SEC Bullish Monitor (sec-api)"** → **Run workflow**.
4. Nakon prvog run-a, otvori `public/feed.xml` (RAW) i dodaj u Inoreader.

## Fino podešavanje
- Promijeni raspored u `.github/workflows/sec-bullish-secapi.yml` (cron).
- Promijeni ključne riječi za 8-K u `fetch_sec_bullish_secapi.py` (`KEYWORDS_8K`).
- Dodaj/izmijeni mapping polja ako tvoj sec-api JSON izgleda drukčije (komentari u kodu).

> Ovaj predložak ne ovisi o sec-api.io SDK-u; radi čistim HTTP pozivima i lako je prilagodljiv.
